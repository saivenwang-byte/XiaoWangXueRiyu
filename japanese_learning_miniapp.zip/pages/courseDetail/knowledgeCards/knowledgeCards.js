Page({
  data: {
    lessonId: '',
    lessonData: null,
    currentCardIndex: 0,
    isFlipped: false,
    audioPlaying: false
  },

  onLoad: function(options) {
    this.setData({
      lessonId: options.lessonId
    });
    this.loadLessonData();
  },

  loadLessonData: function() {
    // 模拟课程数据
    const lessonData = {
      title: '第14课 - 购物与日常活动',
      grammarPoints: [
        {
          title: '动词て形变形规则',
          explanation: '动词的て形变化是日语中的重要语法点，用于连接动作、表示正在进行等。',
          examples: [
            {
              japanese: '書く→書いて',
              chinese: '写→正在写',
              furigana: 'かく→かいて'
            },
            {
              japanese: '食べる→食べて',
              chinese: '吃→正在吃',
              furigana: 'たべる→たべて'
            },
            {
              japanese: 'する→して',
              chinese: '做→正在做',
              furigana: 'する→して'
            }
          ]
        },
        {
          title: '～てください',
          explanation: '表示请求对方做某事的礼貌表达方式。',
          examples: [
            {
              japanese: 'ちょっと待ってください。',
              chinese: '请稍等。',
              furigana: 'ちょっとまってください。'
            },
            {
              japanese: 'ここに名前を書いてください。',
              chinese: '请在这里写下名字。',
              furigana: 'ここになまえをかいてください。'
            }
          ]
        },
        {
          title: '～てから',
          explanation: '表示一个动作完成后再进行另一个动作。',
          examples: [
            {
              japanese: '家へ帰ってから、勉強します。',
              chinese: '回家之后学习。',
              furigana: 'いえへかえってから、べんきょうします。'
            },
            {
              japanese: '食事をしてから、散歩しましょう。',
              chinese: '吃完饭后去散步吧。',
              furigana: 'しょくじをしてから、さんぽしましょう。'
            }
          ]
        }
      ]
    };

    this.setData({
      lessonData: lessonData
    });
  },

  flipCard: function() {
    this.setData({
      isFlipped: !this.data.isFlipped
    });
  },

  nextCard: function() {
    if (this.data.currentCardIndex < this.data.lessonData.grammarPoints.length - 1) {
      this.setData({
        currentCardIndex: this.data.currentCardIndex + 1,
        isFlipped: false
      });
    }
  },

  prevCard: function() {
    if (this.data.currentCardIndex > 0) {
      this.setData({
        currentCardIndex: this.data.currentCardIndex - 1,
        isFlipped: false
      });
    }
  },

  playAudio: function(e) {
    const text = e.currentTarget.dataset.text;
    
    // 检查是否有正在播放的音频
    if (this.data.audioPlaying) {
      return;
    }

    this.setData({
      audioPlaying: true
    });

    // 使用微信语音合成API
    const plugin = requirePlugin('WechatSI');
    plugin.textToSpeech({
      lang: 'ja_JP',
      tts: true,
      content: text,
      success: (res) => {
        const audio = wx.createInnerAudioContext();
        audio.src = res.filename;
        audio.play();
        
        audio.onEnded(() => {
          this.setData({
            audioPlaying: false
          });
        });
        
        audio.onError(() => {
          this.setData({
            audioPlaying: false
          });
          wx.showToast({
            title: '音频播放失败',
            icon: 'none'
          });
        });
      },
      fail: (res) => {
        this.setData({
          audioPlaying: false
        });
        wx.showToast({
          title: '语音合成失败',
          icon: 'none'
        });
      }
    });
  },

  goToDialogue: function() {
    wx.navigateTo({
      url: `/pages/courseDetail/dialoguePractice/dialoguePractice?lessonId=${this.data.lessonId}`
    });
  },

  goToTest: function() {
    wx.navigateTo({
      url: `/pages/courseDetail/test/test?lessonId=${this.data.lessonId}`
    });
  }
});