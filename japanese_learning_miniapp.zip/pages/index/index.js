Page({
  data: {
    lessons: [
      {
        id: 'lesson14',
        title: '第14课',
        subtitle: '购物与日常活动',
        progress: 0,
        completed: false,
        locked: false
      },
      {
        id: 'lesson16',
        title: '第16课',
        subtitle: '描述物体、人物特征',
        progress: 0,
        completed: false,
        locked: true
      },
      {
        id: 'lesson18',
        title: '第18课',
        subtitle: '变化与自我决定',
        progress: 0,
        completed: false,
        locked: true
      }
    ],
    learningStats: {
      totalLearningTime: 0,
      consecutiveDays: 0
    },
    weakPoints: []
  },

  onLoad: function() {
    this.loadUserData();
  },

  onShow: function() {
    this.loadUserData();
  },

  loadUserData: function() {
    const userData = wx.getStorageSync('userData');
    if (userData) {
      const lessons = this.data.lessons;
      
      // 更新课程进度
      lessons.forEach((lesson, index) => {
        if (userData.lessons[lesson.id]) {
          lessons[index].progress = userData.lessons[lesson.id].progress;
          lessons[index].completed = userData.lessons[lesson.id].completed;
          
          // 如果前一课已完成，解锁当前课
          if (index > 0 && lessons[index - 1].completed) {
            lessons[index].locked = false;
          }
        }
      });

      this.setData({
        lessons: lessons,
        learningStats: userData.learningStats,
        weakPoints: this.getWeakPoints(userData)
      });
    }
  },

  getWeakPoints: function(userData) {
    // 简单实现：统计错题最多的知识点
    const wrongQuestions = userData.wrongQuestions || [];
    const pointCount = {};
    
    wrongQuestions.forEach(q => {
      if (pointCount[q.point]) {
        pointCount[q.point]++;
      } else {
        pointCount[q.point] = 1;
      }
    });

    // 转换为数组并排序
    const points = Object.keys(pointCount).map(key => ({
      name: key,
      count: pointCount[key]
    })).sort((a, b) => b.count - a.count);

    return points.slice(0, 3); // 返回前3个薄弱点
  },

  goToLesson: function(e) {
    const lessonId = e.currentTarget.dataset.id;
    const lesson = this.data.lessons.find(l => l.id === lessonId);
    
    if (lesson.locked) {
      wx.showToast({
        title: '请先完成前一课',
        icon: 'none'
      });
      return;
    }

    wx.navigateTo({
      url: `/pages/courseList/courseList?lessonId=${lessonId}`
    });
  },

  goToMyRecord: function() {
    wx.switchTab({
      url: '/pages/myRecord/myRecord'
    });
  }
});